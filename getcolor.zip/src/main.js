import Vue from 'vue'
import App from './App.vue'
import vcolorpicker from 'vcolorpicker'

Vue.use(vcolorpicker)
Vue.config.productionTip = false

new Vue({
  render: h => h(App),
}).$mount('#app')
