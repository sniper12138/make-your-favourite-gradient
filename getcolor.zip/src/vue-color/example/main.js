import Vue from 'vue/dist/vue.min.js'
import App from './App.vue'

/* eslint-disable */
console.log(Vue.version)
new Vue({
  el: '#app-wrap',
  render: h => h(App)
  // components: { App }
})
